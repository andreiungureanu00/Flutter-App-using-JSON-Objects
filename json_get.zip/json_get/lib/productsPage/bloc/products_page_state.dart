abstract class ProductsPageState extends Object {
  const ProductsPageState();
}

class ProductsInit extends ProductsPageState {}
class ProductsLoaded extends ProductsPageState {}
